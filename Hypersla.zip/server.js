const express = require('express');
const axios = require('axios');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

const API_KEY = process.env.HYPERBEAM_API_KEY || 'sk_test_Kb8ZQgsU7SJAuV6UXNgvydVT6baIRKTF4o6Q4nHN6ec';

app.use(express.static(path.join(__dirname, 'public')));

app.get('/start-session', async (req, res) => {
  try {
    const response = await axios.post('https://engine.hyperbeam.com/v0/vm', {}, {
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    res.json({ url: response.data.url });
  } catch (error) {
    console.error('Erro ao criar sessão:', error.response?.data || error.message);
    res.status(500).json({ error: 'Não foi possível iniciar a sessão.' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});